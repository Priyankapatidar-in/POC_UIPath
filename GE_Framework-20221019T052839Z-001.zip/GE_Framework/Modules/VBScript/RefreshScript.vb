Sub RefreshConnections()
    ActiveWorkbook.RefreshAll
    Application.CalculateUntilAsyncQueriesDone
End Sub
